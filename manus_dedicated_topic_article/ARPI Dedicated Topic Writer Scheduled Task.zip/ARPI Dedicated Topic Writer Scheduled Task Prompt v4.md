# ARPI Dedicated Topic Writer Scheduled Task Prompt v4

**Date-safe, path-safe, and publication-safe production workflow**

## Task Objective

Execute the ARPI Dedicated Topic Writer workflow and create exactly one upload-ready evergreen draft for the editorial date assigned by the schedule. Use the `arpi-dedicated-topic-writer` skill as the governing workflow. Do not publish the article.

## Canonical Files

*   **Prompt:** `/home/ubuntu/projects/dedicated-topics-rai-92c0e351/ARPI_Dedicated_Topic_Writer_Scheduled_Task_Prompt_v4.md`
*   **Calendar:** `/home/ubuntu/projects/dedicated-topics-rai-92c0e351/ARPI_Content_Calendar_Strategy_v5a.xlsx`
*   **Live website:** `https://www.robotaigeek.com/`

Verify that both local files exist before doing any other work. If either path is missing, report the missing path and stop. Do not use a similarly named file or another project directory as a fallback.

## Mandatory Preflight

### 1. Resolve the Editorial Date

1.  Derive `RUN_DATE` from the scheduled trigger timestamp after converting it to the schedule timezone, **Asia Shanghai**.
2.  Never use the sandbox date, UTC date, model-assumed date, or file modification date as `RUN_DATE`.
3.  Format `RUN_DATE` as `YYYY-MM-DD` and log it before opening the workbook.
4.  For a manual rerun, use the date explicitly requested by the user. If no date is supplied, derive the current date in Asia Shanghai.

### 2. Match the Calendar Exactly

1.  Open Tab 4, `4. Week-by-Week (Wk 1–8)`.
2.  Find the row whose Date column exactly equals `RUN_DATE`.
3.  Extract the Week label, Day, Article Title, Asset Class, and Post Slot.
4.  If there is no exact match, report that no post is scheduled and stop.
5.  Do not choose the closest upcoming, previous, or unfilled slot.

### 3. Check the Live Website

1.  Open the RobotAIGeek website before research.
2.  Search the recent article archive for the exact scheduled title and close title variants.
3.  If the topic is already live, report the matching title, publication date, and URL, then stop.
4.  Do not create a duplicate draft unless the user explicitly asks for a revision.
5.  Review the latest 3 to 5 relevant hero images and record the visual patterns that the new hero must avoid.

### 4. Record the Preflight

| Field | Required record |
| :--- | :--- |
| Editorial timezone | Asia Shanghai |
| RUN_DATE | YYYY-MM-DD |
| Prompt path | Exact existing path |
| Calendar path | Exact existing path |
| Calendar match | Title, Asset Class, and Post Slot |
| Website preflight | Clear to draft, or duplicate URL and stop |

## Load the Content Framework

1.  Open Tab 5, `5. Content Framework`, in the same workbook.
2.  Find the section corresponding to the exact Post Slot from Tab 4.
3.  Use its Purpose and Subheaders as the required article structure.
4.  Do not skip, merge, or replace required headings without explaining the change in the editor summary.

## Market-Development Scan and Source Standard

**Before conducting narrow article-specific research, execute a broad market-development scan.** Search for recent major conferences, product announcements, standards releases, regulatory filings, and deployment developments relevant to the scheduled topic. Filter these developments for relevance and use them to shape the article's current-market context.

Use **Tier 1 sources for every pricing, market size, shipment, wage, tariff, revenue, and procurement figure**.

*   Approved Tier 1 sources include IFR, World Bank, ILO, IMF, OECD, national statistical agencies, national customs authorities, central banks, official procurement portals, and publicly listed company filings.
*   Use named Tier 2 research firms and peer-reviewed research only for context and trends. Do not use Tier 2 sources for a key quantitative claim when a primary source exists.
*   Never cite LinkedIn articles, personal blogs, Medium, Substack, Reddit, Quora, AI-generated content, press release aggregators, SEO pricing guides, or vendor marketing pages for factual claims.
*   Vendor documentation may support technical specifications only.

For every key figure, navigate to the primary source URL and confirm the value, period, units, currency, geographic scope, and disclosure scope. Record the source title, publisher, date, URL, and supported claim. If a figure cannot be verified, omit it or label it directional and add an Editor Note. Never invent a value.

## Originality Standard

Include at least one analytical layer not present in any single cited source. Suitable methods include a country comparison, buyer decision matrix, scope-adjusted manufacturer ranking, cross-asset class comparison, total cost model, procurement scenario, or sensitivity analysis. State the method and its limitations. Do not present unlike company disclosure scopes as directly comparable.

## Article Requirements

*   Write 800 to 1,200 words in a professional, analytical, buyer-focused Wise Peer voice.
*   Open with a specific commercial insight and use the Tab 5 subheaders as H2 headings.
*   Use flowing paragraphs. Use bullets only in a clearly labelled checklist or questions section.
*   Do not use dashes as parenthetical breaks. Avoid formulaic AI-sounding phrases.
*   Include inline numeric citations and a References section with direct primary URLs.
*   Do not mention workflow names, internal instructions, or the publication name in the article body.
*   Close with a definitive forward-looking statement linked to the ARPI procurement or investment thesis.

## Visual and Data Assets

*   Generate a photorealistic generic hero image in true JPG format with a 16:9 aspect ratio.
*   Use no logos, branding, text overlays, or watermarks.
*   Make the hero visually distinct from the latest 3 to 5 relevant website heroes reviewed during preflight.
*   Save the hero as `[YYYYMMDD]_[AssetClass]_Post[SlotNumber]_hero.jpg`.
*   Create precise table graphics with deterministic code and save them as PNG.
*   Export underlying values, formulas, a source ledger, and analytical notes to a formatted Excel workbook.

## Output and Quality Control

Save the article as `RobotAIGeek_Draft_[YYYYMMDD]_[AssetClass]_Post[SlotNumber].md`. The date in the filename must equal `RUN_DATE`.

*   Include Title, Summary, SEO Meta Title, SEO Meta Description, Tags, Asset Class, Post Slot, Scheduled Date, Status, Hero Image, and Table Images in the metadata block.
*   Verify the exact calendar title and Post Slot, all required Tab 5 headings, the 800 to 1,200 word count, citation completeness, prohibited source exclusions, original analysis, dash restrictions, JPG format, 16:9 hero ratio, legible PNG tables, and workbook integrity.
*   Deliver the Markdown draft, hero image, table graphics, Excel workbook, and quality control report.
*   Briefly report the preflight result, source tiers, limitations, original analytical layer, and hero differentiation.

## Stop Conditions

*   A canonical input path is missing.
*   No exact Tab 4 row matches `RUN_DATE`.
*   The scheduled topic is already published on the live website.
*   The required Content Framework section is missing.
*   A material factual claim cannot be verified adequately.

When a stop condition occurs, explain it clearly and do not draft an alternative topic. Never auto-publish. Wait for user approval.
