# ARPI Dedicated Topics: Word-First Deliverable Update

**Status date:** 21 July 2026, Asia/Shanghai

## Decision

Future dedicated-topic article packages will use a **Word-first `.docx` format** rather than a raw Markdown article as the primary editorial deliverable. The attached Blackstone and FUTRONIC article was used as a formatting benchmark only. Its public content, source claims, and company-specific language are not reused.

The rationale is practical. A raw Markdown article downloaded as Word is difficult to read and not suitable for an editor or uploader who needs a clean editorial package. The new format preserves analytical rigor while presenting the article as a readable, upload-ready document.

## New Word package standard

| Component | Required treatment |
|---|---|
| Cover page | Large centered headline, compact dateline, 16:9 hero image, and image credit. |
| Metadata page | Two-column upload metadata table with headline, slug, summary, category, tags, SEO fields, image filename, and publication control. |
| Article body | Clear dark-blue Word-native headings, readable paragraphs, inline citations, and no raw Markdown syntax. |
| Analytical tables | Embedded legible PNG comparison tables or Word-native tables when appropriate. |
| Closing page | Direct numbered references and a concise informational disclaimer. |
| Delivery set | `.docx` article, hero JPG, table PNGs, Excel workbook, source ledger, analytical notes, and quality-control report. |

## Workflow and schedule changes

The `arpi-dedicated-topic-writer` skill now requires the file pattern:

`RobotAIGeek_Draft_[YYYYMMDD]_[AssetClass]_Post[SlotNumber].docx`

It uses `scripts/generate_word_article.py` to generate the package from a structured JSON payload. The scheduled-task playbook and v4 prompt now require the `.docx` package and explicitly prohibit raw Markdown as the user-facing article deliverable.

The active schedule has been updated with this requirement. Its weekday 06:00 Asia/Shanghai cadence, exact-date calendar checks, current-market relevance gate, live duplicate check, and no-auto-publish policy remain unchanged.

## Validation

| Validation item | Result |
|---|---|
| Skill structure | Passed the skill validator. |
| Word generator syntax | Passed Python compilation. |
| Test document creation | Passed; the output is a Microsoft Word 2007+ `.docx` file. |
| Visual layout review | Passed: cover, hero credit, metadata table, styled headings, references, and disclaimer rendered correctly. |
| Readability refinement | Applied: duplicate body-heading behaviour was removed after the first test. |

## Operational notes

The new package is intentionally restrained. It uses a clear dark-blue hierarchy, generous white space, structured metadata, and clean visual assets. It does not imitate the benchmark’s content and does not introduce branding, promotional claims, or unsupported design elements.

Historical Markdown drafts remain available as internal working artifacts. They are not the primary article delivery format going forward. No previously prepared article has been published or uploaded.

## Next scheduled-run expectation

The next dedicated-topic run should generate the Word document as the principal article deliverable, test that it opens, verify that the cover, metadata table, body, references, and disclaimer are present, then deliver the `.docx` package alongside the supporting assets for editorial approval.
