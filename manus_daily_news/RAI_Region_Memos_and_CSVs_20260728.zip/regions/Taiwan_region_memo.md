# Taiwan Region Memo: Robotics & Embodied-AI Primary Sources

## Coverage Logic
The coverage strategy for Taiwan focuses on its unique position as a global powerhouse in semiconductor manufacturing, electronics supply chain, and industrial automation. The sources are categorized into:
1. **Government & Policy**: Key ministries (MOEA, MODA) and councils (NSTC) that drive national AI and robotics initiatives, fund research, and manage science parks (Hsinchu, Southern, Central).
2. **Disclosure & Patents**: TWSE MOPS for official corporate filings and earnings of publicly traded robotics companies, and TIPO for patent trends.
3. **Associations & Exhibitions**: Major industry bodies (TAIROA, TEEMA, SEMI Taiwan) and exhibitions (Computex, TAIROS) that serve as hubs for industry alliances, product launches, and supply chain news.
4. **Research Institutes & Universities**: Premier research organizations (ITRI, III, Academia Sinica) and top engineering universities (NTU, NTHU, NCKU, NYCU) that lead fundamental and applied research in AI and robotics.
5. **Company Newsrooms**: Leading manufacturers and tech companies (TSMC, Foxconn, Quanta, Advantech, Techman Robot, HIWIN, Solomon) that are at the forefront of AI infrastructure, smart manufacturing, and robotics components.

## Top 10 Priority Sources
1. **Taiwan Semiconductor Manufacturing Company (TSMC)**: The world's largest contract chipmaker; crucial for tracking advancements in semiconductor technology that power AI and robotics.
2. **Hon Hai Technology Group (Foxconn)**: A major global manufacturer; essential for news on AI servers, smart manufacturing, and robotics initiatives.
3. **Techman Robot**: A leading global collaborative robot (cobot) manufacturer; key for tracking innovations in AI-driven cobots.
4. **Industrial Technology Research Institute (ITRI)**: Taiwan's premier applied technology research institute; a primary source for breakthroughs in robotics, automation, and technology transfer.
5. **National Science and Technology Council (NSTC)**: The main government body funding science and technology; vital for tracking national AI/robotics initiatives and major research grants.
6. **TWSE Market Observation Post System (MOPS)**: The official disclosure portal; indispensable for verifying corporate filings, earnings, and material events of publicly traded tech companies.
7. **Solomon Technology**: A leader in 3D vision and AI robotics solutions; important for tracking advancements in machine vision and intelligent robotics.
8. **Taiwan Automation Intelligence and Robot Show (TAIROS)**: Taiwan's sole international exhibition for industrial robots; a major venue for product launches and industry trends.
9. **Advantech**: A major provider of industrial PCs and IoT computing; key for news on edge AI and automation hardware.
10. **Taiwan Automation Intelligence and Robotics Association (TAIROA)**: The major robotics association; crucial for tracking industry alliances, member news, and policy advocacy.

## Monitoring Cadence Advice
- **Daily**: Government press releases (NSTC, MOEA), TWSE MOPS filings, and major company newsrooms (TSMC, Foxconn) during earnings seasons.
- **Weekly**: Research institute updates (ITRI, III), university lab news, and other company newsrooms (Advantech, Techman Robot, HIWIN).
- **Event-driven**: Exhibitions (Computex, TAIROS, Automation Taipei) and association announcements (TAIROA, TEEMA).

## Access Caveats
- **Language**: While many sources offer English versions, the Chinese sites are often updated more frequently and contain more comprehensive information. Monitoring should prioritize the Chinese versions (`zh` or `zh+en`) using translation tools if necessary.
- **RSS Availability**: RSS feeds are available for some government sites (e.g., MOEA, NSTC), but most company newsrooms and disclosure portals (like MOPS) require page scraping or API access.
- **Paywalls/Logins**: Most primary sources listed are publicly accessible without paywalls. However, MOPS requires specific ticker or keyword searches to extract relevant filings.

## Demoted Secondary Media
The following commonly-used secondary media should be demoted to a verification-only role, as they aggregate or report on news that originates from the primary sources listed above:
- **DigiTimes**: While a prominent tech news outlet, it is a secondary source. Its reports should be verified against primary company announcements or MOPS filings.
- **General Media Wires (e.g., CNA - Central News Agency)**: Useful for broad coverage but should not be treated as the origination point for specific corporate or technological developments.
