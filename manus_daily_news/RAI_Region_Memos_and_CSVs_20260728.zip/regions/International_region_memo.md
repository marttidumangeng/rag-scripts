# International Region Robotics Sources Memo

## Coverage Logic
The coverage strategy for the International region focuses on capturing the highest-level global governing bodies, standards organizations, and international associations that shape the robotics and embodied-AI landscape. The logic is divided into several key pillars:
1. **Industry & Professional Associations**: Organizations like the International Federation of Robotics (IFR) and IEEE Robotics and Automation Society (RAS) are critical for global market statistics, industry trends, and academic consensus.
2. **Standards Bodies**: ISO TC 299 and IEC are essential for tracking the development of safety and performance standards, which dictate market access and product design globally.
3. **Intergovernmental Organizations**: UN agencies (ITU, WIPO, ILO, UNIDO) and organizations like the OECD and World Economic Forum (WEF) provide the macro-level policy, patent, and economic context for automation and AI.
4. **Academic & Open Source**: arXiv (cs.RO) and the Open Source Robotics Foundation (OSRF) capture the bleeding edge of research and software development before commercialization.
5. **Major Exhibitions**: Trade fairs like automatica and Hannover Messe are primary venues for product launches and industry announcements.

## Top 10 Priority Sources
1. **International Federation of Robotics (IFR)**
   *Rationale*: The definitive source for global robotics market statistics and the annual World Robotics report.
2. **arXiv cs.RO**
   *Rationale*: The primary preprint server where breakthrough robotics research is published months before formal peer review.
3. **Open Source Robotics Foundation (OSRF) / ROS Discourse**
   *Rationale*: The central hub for updates on ROS (Robot Operating System), the foundational software for modern robotics.
4. **ISO TC 299 Robotics**
   *Rationale*: The authoritative body for international robotics standards, crucial for understanding future compliance requirements.
5. **World Intellectual Property Organization (WIPO)**
   *Rationale*: Provides macro-level data on global patent trends and the intersection of AI and intellectual property.
6. **OECD.AI**
   *Rationale*: The leading intergovernmental observatory for tracking national AI policies and principles globally.
7. **IEEE Robotics and Automation Society (RAS)**
   *Rationale*: The premier professional society, organizing the most important academic conferences (ICRA, IROS).
8. **ITU AI for Good**
   *Rationale*: The UN's primary platform for AI and robotics initiatives aimed at sustainable development.
9. **automatica**
   *Rationale*: The leading European trade fair for smart automation and robotics, a major source of product announcements.
10. **UN Industrial Development Organization (UNIDO)**
    *Rationale*: Key source for initiatives on industrial AI and manufacturing automation in developing and emerging economies.

## Monitoring Cadence Advice
* **Daily**: arXiv cs.RO (via RSS) and OSRF/ROS Discourse, as these have high-frequency, continuous updates.
* **Weekly**: WIPO, OECD.AI, and UNIDO for policy and patent updates.
* **Event-Driven/Seasonal**: IFR (annual reports), IEEE RAS/ICRA/RSS (conference seasons), automatica/Hannover Messe (trade fair dates), and ISO/IEC (standards publication cycles).

## Access Caveats
* **RSS Availability**: Very few international organizations offer dedicated RSS feeds for their press rooms. arXiv cs.RO is a notable exception. Most sources will require custom page scraping.
* **Anti-Bot Protection**: Some sites, such as the IEC, employ JavaScript-based anti-bot protection (e.g., Cloudflare), which complicates automated scraping.
* **Broad Focus**: Organizations like the World Bank, ILO, and WEF cover a vast array of topics. Scraping these sites requires strict keyword filtering (e.g., "robotics", "automation") to avoid noise.
* **URL Volatility**: Conference websites (like ICRA) often change their base URL every year (e.g., 2024.ieee-icra.org to 2025.ieee-icra.org), requiring annual updates to the monitoring system.

## Demoted Sources (Verification-Only)
* **IEEE Spectrum Robotics**: While producing excellent, high-quality journalism, it is a secondary media outlet, not a primary originator of news. It should be used strictly for discovering trends and verifying claims, rather than as a first-hand source.
* **General Tech Media (e.g., TechCrunch, The Verge)**: These outlets aggregate and rewrite press releases. They should be entirely excluded from the primary source registry and used only for context or verification.
