# United States Region Memo: Robotics & Embodied-AI First-Hand Sources

## Coverage Logic
The United States is the global leader in advanced robotics research, embodied AI, and commercial deployment. Our coverage strategy focuses on capturing news at the point of origination across five key pillars:
1. **Government & Regulatory**: Tracking federal funding (DARPA, NSF, DOE), procurement (SAM.gov), medical clearances (FDA), and export controls (BIS) that shape the market.
2. **Academic & Research Institutes**: Monitoring top-tier university labs (CMU, MIT, Stanford, UC Berkeley) and preprint servers (arXiv) where fundamental breakthroughs in AI and robotics first appear.
3. **Corporate Research & Big Tech**: Following the AI foundation model developers (Google DeepMind, OpenAI, Meta AI, Microsoft Research) that are increasingly powering embodied AI.
4. **Startups & Commercial Deployments**: Tracking the rapidly evolving humanoid and autonomous systems startup ecosystem (Figure, Apptronik, Physical Intelligence, Agility Robotics).
5. **Industry Associations**: Utilizing organizations like A3 and MassRobotics for macro-level industry statistics and regional ecosystem updates.

## Top 10 Priority Sources
1. **SEC EDGAR Full-Text Search API**: The definitive source for financial disclosures, IPOs, M&A, and executive changes for publicly traded robotics companies.
2. **FDA 510(k) Premarket Notification Database**: The critical bottleneck and first public indicator for medical and surgical robotics market entry.
3. **Tesla Investor Relations**: High market impact source for updates on the Optimus humanoid robot and autonomous driving technology.
4. **Nvidia Newsroom**: Essential for tracking the compute infrastructure, Isaac platform updates, and AI foundation models driving the robotics industry.
5. **arXiv cs.RO (Robotics)**: The earliest indicator of academic and corporate research breakthroughs before formal publication or press releases.
6. **Google DeepMind Blog**: Crucial for updates on Gemini Robotics and advanced AI models being applied to physical systems.
7. **Figure AI News**: Leading indicator for the commercialization and deployment of general-purpose humanoid robots.
8. **SAM.gov Opportunities API**: The primary source for tracking federal and defense procurement contracts for unmanned and autonomous systems.
9. **Boston Dynamics News**: The pioneer in legged robotics, providing key updates on commercial deployments of Atlas and Spot.
10. **Physical Intelligence**: High-profile startup developing general-purpose AI brains for robots, representing the cutting edge of embodied AI.

## Monitoring Cadence Advice
- **Daily (P0)**: SEC EDGAR, FDA 510(k), arXiv cs.RO, SAM.gov, and major corporate IR feeds (Tesla, Nvidia) should be monitored daily via RSS or API for immediate market-moving news.
- **Weekly (P1)**: University research labs, corporate research blogs (DeepMind, OpenAI, Meta), and industry associations should be scraped or checked weekly for research breakthroughs and ecosystem updates.
- **Event-Driven/Monthly (P2)**: Startup newsrooms, conference acceptances (CoRL, RSS), and macroeconomic data (Census M3) can be monitored on an event-driven or monthly basis.

## Access Caveats
- **APIs**: SEC EDGAR and SAM.gov have rate limits and require proper API key management and request throttling.
- **Search Queries**: USPTO and FDA databases require complex, well-maintained boolean search queries to filter out noise and capture relevant robotics IP/clearances.
- **Scraping**: Many startup and university lab pages lack RSS feeds and require custom web scrapers that may break when site layouts change.
- **Volume**: arXiv cs.RO produces a high volume of preprints; an LLM-based filter is recommended to identify truly impactful papers.

## Demoted Secondary Media (Verification-Only Tier)
The following commonly-used secondary media sources should be demoted to a verification-only role, as they aggregate news rather than originate it:
- *The Robot Report*
- *IEEE Spectrum* (Robotics section)
- *TechCrunch* (Robotics/AI tags)
- *MIT Technology Review*
- *Robotics Business Review*
