# South Korea Robotics First-Hand Sources Memo

## Coverage Logic
The South Korean robotics ecosystem is highly concentrated around government-led initiatives, major conglomerates (chaebols), and top-tier research institutes. Our coverage strategy focuses on these three pillars:
1. **Government & Disclosure**: South Korea's robotics industry is heavily subsidized and guided by government policy. Ministries like MOTIE and MSIT, along with agencies like KIRIA and KIAT, are critical for policy, funding, and strategic direction. Disclosure portals like DART and KIND are essential for tracking corporate investments, M&A, and financial health.
2. **Research Institutes & Universities**: South Korea boasts world-class robotics research, particularly in humanoids, AI, and industrial automation. Institutions like KAIST, KIST, ETRI, and KIMM are the birthplaces of foundational technologies and spin-off companies.
3. **Corporate Newsrooms**: The commercialization of robotics is driven by major conglomerates (Hyundai Motor Group, Samsung, LG, Hanwha, Doosan) and specialized robotics firms (Rainbow Robotics, Neuromeka, Robotis). Tracking their corporate newsrooms provides early signals on product launches, partnerships, and strategic shifts.

## Top 10 Priority Sources
1. **DART (Financial Supervisory Service)**: The ultimate source for verified corporate filings, M&A activities, and financial disclosures of publicly traded robotics companies.
2. **MOTIE (Ministry of Trade, Industry and Energy)**: The primary government body shaping national robotics policy, funding major initiatives, and launching strategic alliances like the K-Humanoid Alliance.
3. **Hyundai Motor Group / Boston Dynamics**: A global powerhouse in robotics, their newsroom is critical for updates on humanoid development, industrial automation, and strategic investments.
4. **Samsung Electronics**: With its dedicated robotics division (RX) and significant investments in companies like Rainbow Robotics, Samsung is a major catalyst in the industry.
5. **KAIST (Korea Advanced Institute of Science and Technology)**: The premier research university for robotics in South Korea, consistently producing breakthrough technologies and spin-offs.
6. **KIRIA (Korea Institute for Robot Industry Advancement)**: The central agency for executing government robotics policies, supporting commercialization, and fostering industry growth.
7. **Rainbow Robotics**: A leading humanoid and collaborative robot company, closely tied to Samsung, making it a bellwether for the domestic robotics market.
8. **LG Electronics / LG AI Research**: A major player in service robots and AI, with strategic investments in companies like Bear Robotics.
9. **KIST (Korea Institute of Science and Technology)**: A leading national research institute with a strong focus on advanced robotics, AI, and healthcare applications.
10. **KIPRIS (Korea Intellectual Property Rights Information Service)**: Essential for tracking patent filings, which provide early indicators of technological trends and corporate R&D focus.

## Monitoring Cadence Advice
- **Daily (P0)**: DART, KIND, MOTIE, Hyundai Motor Group, Samsung Electronics. These sources provide market-moving news, regulatory filings, and major corporate announcements that require immediate attention.
- **2-3x/Week (P1)**: Major research institutes (KAIST, KIST, ETRI), key robotics companies (Rainbow Robotics, Doosan Robotics, Hanwha Robotics, LG Electronics), and government agencies (KIRIA, MSIT). These sources produce regular updates on research breakthroughs, product launches, and policy implementation.
- **Weekly/Event-Driven (P2)**: Specialized robotics firms (Neuromeka, Robotis, Bear Robotics, Wonik Robotics), universities, associations (KAR), and exhibitions (RobotWorld). These sources are more sporadic but provide valuable insights into niche technologies, industry events, and emerging trends.

## Access Caveats
- **Language**: While many major corporations and top universities offer English press releases, government ministries, smaller companies, and detailed technical reports are often exclusively in Korean. Translation tools or native speakers are necessary for comprehensive coverage.
- **Paywalls/Logins**: Government portals (MOTIE, KIRIA) and corporate newsrooms are generally open access. However, deep patent searches on KIPRIS or detailed financial data on DART may require registration or API keys for automated scraping.
- **RSS Availability**: RSS feeds are relatively uncommon among South Korean corporate newsrooms and government sites. Automated monitoring will largely rely on custom page scrapers or APIs (e.g., DART OpenAPI).

## Demoted Secondary Media
The following general media outlets, while useful for context, should be demoted to a verification-only role, as they typically aggregate or rewrite news originating from the primary sources listed above:
- Korea Herald
- Korea Times
- Yonhap News Agency
- Seoul Economic Daily
- The Elec
- BusinessKorea
