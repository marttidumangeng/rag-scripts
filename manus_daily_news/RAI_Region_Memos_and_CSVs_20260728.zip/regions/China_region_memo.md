# RobotAIGeek Primary Source Registry Memo: China (Mainland)

## Coverage Logic
The coverage strategy for China focuses on establishing a robust, first-hand intelligence gathering network that bypasses secondary media aggregators. The logic is structured across five key pillars:
1. **Government & Policy:** Central ministries (MIIT, NDRC, MOST) and key municipal/provincial governments (Beijing, Shanghai, Shenzhen) are prioritized to capture top-down policy directives, funding allocations, and strategic plans for the robotics and embodied AI sectors.
2. **Corporate Disclosures:** Official exchange portals (CNINFO, SSE, SZSE, BSE) are utilized to track financial performance, M&A activities, and regulatory filings of publicly listed robotics companies, ensuring accurate and timely corporate intelligence.
3. **Company Newsrooms:** Direct monitoring of newsrooms and PR pages of leading robotics firms (e.g., Unitree, UBTECH, AgiBot) captures product launches, technological breakthroughs, and corporate milestones straight from the source.
4. **Research & Academia:** Top-tier research institutes (CAS IA, BAAI) and universities (Tsinghua, Zhejiang University) are included to monitor fundamental research advancements, patent filings, and academic publications that signal future industry trends.
5. **Industry Associations & Exhibitions:** Key associations (CRIA, CAA) and major exhibitions (WRC, WAIC) provide macro-level industry statistics, standardization efforts, and a consolidated view of the competitive landscape.

## Top 10 Priority Sources
1. **MIIT (Ministry of Industry and Information Technology):** The primary regulatory body for China's tech sector; crucial for national robotics industry policies, standard announcements, and strategic roadmaps.
2. **CNINFO (巨潮资讯网):** The official disclosure portal for Chinese stock exchanges; essential for accessing financial reports and corporate actions of listed robotics companies via API.
3. **Unitree Robotics Newsroom:** A leading player in quadruped and humanoid robots; their newsroom is the first point of contact for major product launches and updates.
4. **UBTECH Investor Relations:** As a major listed humanoid robot company, their IR page provides critical financial updates and corporate announcements.
5. **AgiBot (Zhiyuan) Newsroom:** A rapidly growing humanoid robot startup; monitoring their newsroom captures key product developments and company milestones.
6. **Beijing Municipal Government Policy Page:** Beijing is a major hub for humanoid robotics innovation; this source tracks local policies, subsidies, and support initiatives.
7. **CAS Institute of Automation:** A premier research institute; tracking their lab news provides early signals on fundamental AI and robotics research breakthroughs.
8. **World Robot Conference (WRC):** The largest robotics exhibition in China; their announcements highlight major product debuts and industry trends.
9. **CCGP (China Government Procurement Network):** Essential for tracking government procurement bids and awards, indicating public sector demand for robotics solutions.
10. **State Council Policy Database:** Provides top-level national policies and directives on AI and robotics, setting the overarching agenda for the industry.

## Monitoring Cadence Advice
- **Daily (P0):** Government policy pages (MIIT, NDRC, State Council), exchange disclosure portals (CNINFO, SSE, SZSE), and procurement portals (CCGP). These sources generate high-impact, time-sensitive information.
- **2-3x/Week (P1):** Company newsrooms of leading firms (Unitree, UBTECH, AgiBot), major research institutes (CAS IA, BAAI), and key industry associations (CRIA). These sources provide regular updates on product launches and research advancements.
- **Event-Driven/Monthly (P2):** University lab news, exhibition announcements (WRC, WAIC), and patent databases (CNIPA). These sources are best monitored around specific events or on a monthly basis for broader trends.

## Access Caveats
- **Language:** The vast majority of primary sources (government, disclosures, procurement) are exclusively in Simplified Chinese (zh). Bilingual (zh+en) support is mostly limited to company newsrooms and major exhibitions.
- **Paywalls/Logins:** Most government and disclosure portals are free and open access. However, some corporate IR pages or specific patent databases may require registration.
- **RSS Availability:** RSS feeds are extremely rare across Chinese primary sources. Most monitoring will require custom page scraping or API integration (e.g., CNINFO API).
- **Network Restrictions:** Some government websites may have geo-blocking or strict anti-scraping measures, requiring localized IP addresses or careful rate limiting.

## Demoted Secondary Media (Verification-Only Tier)
The following commonly-used secondary media and aggregators have been demoted to a verification-only role, as they do not originate news:
- **36Kr (36氪):** Useful for verifying funding rounds and general tech trends, but not a primary source.
- **Jiqizhixin (机器之心):** Good for AI and robotics news aggregation and analysis, but relies on primary announcements.
- **QbitAI (量子位):** Similar to Jiqizhixin, useful for tracking AI developments but not an originator.
- **GGII (高工机器人):** Provides industry reports and analysis, but data is often aggregated or derived.
- **IT Juzi (IT桔子):** A database for startup funding and investments; useful for verification but not a primary disclosure source.
