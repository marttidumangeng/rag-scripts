# Hong Kong Region Memo: Robotics & Embodied-AI First-Hand Sources

## Coverage Logic
The coverage strategy for Hong Kong focuses on its unique position as a financial hub, a center for academic research, and a gateway for mainland Chinese robotics companies expanding globally. The sources are categorized as follows:
- **Government & Funding (P0/P1):** Crucial for tracking policy direction, smart city initiatives, and R&D funding. Key sources include ITIB, ITC, and the Innovation and Technology Fund (ITF).
- **Disclosure (P0):** HKEXnews is the definitive source for financial filings, IPO prospectuses, and corporate actions of listed robotics companies (e.g., UBTECH, Horizon Robotics, XPeng).
- **Research & Universities (P1/P2):** Hong Kong's universities (HKUST, CUHK, HKU, PolyU, CityU) are major incubators for robotics talent and spin-offs (e.g., DJI originated from HKUST). InnoHK clusters (like AIR@InnoHK and COCHE) represent significant government-backed research efforts.
- **Companies (P0/P1):** Focuses on IR pages of listed companies and newsrooms of major unlisted players (e.g., Hai Robotics, Geek+, SmartMore) that have significant operations or origins in Hong Kong.
- **Exhibitions (P1/P2):** HKTDC events and InnoEX are key venues for product launches and industry networking.

## Top 10 Priority Sources
1. **HKEXnews (Disclosure - P0):** The absolute primary source for verified financial and corporate data on HK-listed robotics firms. Essential for tracking IPOs and major investments.
2. **Innovation and Technology Commission (ITC) (Government - P0):** The main distributor of government R&D funding, crucial for tracking where public money is flowing in the robotics sector.
3. **Hong Kong Science and Technology Parks (HKSTP) (Government - P0):** The primary incubator for robotics startups in HK; news here often precedes broader media coverage of emerging companies.
4. **InnoHK (Government - P0):** The umbrella for major research clusters like AIR@InnoHK, providing early signals on breakthrough research and significant lab funding.
5. **UBTECH Investor Relations (Company - P0):** Direct source for financials and mass production milestones of a leading humanoid robotics company.
6. **Horizon Robotics Investor Relations (Company - P0):** Key source for updates on autonomous driving computing solutions and corporate financials.
7. **HKUST Cheng Kar-Shun Robotics Institute (CKSRI) (University - P1):** A powerhouse of robotics research and a frequent origin point for successful spin-offs.
8. **Cyberport (Government - P1):** Alongside HKSTP, a major hub for AI and tech startups, providing news on funding and partnerships.
9. **InvestHK (Government - P1):** Tracks foreign and mainland robotics companies setting up or expanding operations in Hong Kong.
10. **Hai Robotics (Company - P1):** A major player in warehouse automation with strong HK ties; their newsroom provides direct updates on product launches and global expansion.

## Monitoring Cadence Advice
- **Daily:** HKEXnews (for filings), HKSAR Government Press Releases (via RSS with strict keyword filtering).
- **Weekly:** Government bureaus (ITIB, ITC), tech hubs (HKSTP, Cyberport), and major research institutes (ASTRI).
- **Monthly:** University labs, company newsrooms (for non-financial updates), and funding scheme announcements (ITF).
- **Event-Driven:** Company IR pages (around earnings seasons or major announcements), exhibition press releases (Spring/Autumn for HKTDC, April for InnoEX).

## Access Caveats
- **Language:** Most official government and university sources in Hong Kong are bilingual (English and Traditional Chinese). However, some local startup news or specific lab updates might lean towards Traditional Chinese.
- **Paywalls:** First-hand sources listed here are generally free to access.
- **RSS Availability:** RSS is limited. The general HKSAR Government Press Releases has an RSS feed, but most specific bureau, university, and company pages require page scraping or manual checking.
- **HKEXnews:** The search interface can be clunky; programmatic access or scraping requires careful handling of session states or using their specific search parameters.

## Demoted Secondary Media (Verification-Only)
The following commonly used media sources should be demoted to a verification-only role, as they are aggregators or secondary reporters rather than originators:
- **South China Morning Post (SCMP):** While excellent for context and analysis, they are a secondary news outlet.
- **Tech in Asia:** An aggregator and secondary reporter of startup news.
- **Hong Kong Economic Times (HKET) / Hong Kong Economic Journal (HKEJ):** Financial news outlets that report on filings and press releases, but the primary source remains HKEXnews or the company IR pages.
