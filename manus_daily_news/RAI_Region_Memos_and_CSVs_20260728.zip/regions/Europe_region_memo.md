# Europe Robotics Primary Source Registry Memo

## Coverage Logic
The European robotics ecosystem is characterized by strong government involvement, collaborative research networks, and a robust industrial base. Our coverage strategy reflects this structure:
1. **Government & Policy (EU & National):** We prioritize EU-level institutions (European Commission, AI Office) and national agencies (Germany's BMWK, UK's DSIT, France's Bpifrance) because they drive funding, regulation (e.g., AI Act), and strategic direction.
2. **Research & Innovation:** Europe has world-leading research institutes (Fraunhofer, DLR, ETH Zurich, IIT). We focus on these labs as they are the birthplace of fundamental breakthroughs in legged robotics, industrial automation, and AI.
3. **Industry & Companies:** We track major industrial players (ABB, KUKA, Universal Robots) and innovative startups/scale-ups (1X, ANYbotics, Exotec) to capture product launches, financial health, and market adoption.
4. **Associations & Exhibitions:** Organizations like VDMA and events like automatica provide crucial macro-level statistics and industry trends.

## Top 10 Priority Sources

1. **European Commission Digital Strategy News:** The definitive source for EU-wide policy, funding, and regulatory announcements regarding AI and robotics.
2. **Germany BMWK (Federal Ministry for Economic Affairs and Climate Action):** Crucial for tracking Germany's Industry 4.0 initiatives and national funding, which heavily influence the European market.
3. **Fraunhofer IPA:** A powerhouse of applied research in manufacturing engineering and automation; essential for technology transfer news.
4. **DLR Robotics and Mechatronics Center:** World-leading research in space, medical, and industrial robotics; a key source for fundamental breakthroughs.
5. **ETH Zurich Robotic Systems Lab (RSL):** The premier academic source for advancements in legged robotics and autonomous systems.
6. **IIT Genoa (Istituto Italiano di Tecnologia):** The leading center for humanoid robotics research (iCub, ergoCub) in Europe.
7. **ABB Robotics:** As a global leader with a strong European base, their newsroom is vital for tracking industrial robotics trends and product launches.
8. **Universal Robots:** The pioneer in collaborative robots; their updates are essential for monitoring the cobot market.
9. **1X Technologies:** A key player in the emerging humanoid robot market; crucial for tracking developments in AI-driven labor automation.
10. **VDMA Robotics + Automation:** The most authoritative source for European robotics market statistics and industry trends.

## Monitoring Cadence Advice
- **Daily (P0):** Government policy portals (EU Commission, BMWK, DSIT), major funding announcements (Bpifrance), and top-tier research/company newsrooms (Fraunhofer, ABB, 1X).
- **Weekly (P1):** University lab updates, association news (euRobotics, Make UK), patent filings (EPO), and mid-tier company newsrooms.
- **Monthly/Event-driven (P2):** Macroeconomic statistics (Eurostat), exhibition announcements (automatica, Hannover Messe), and specific project updates.

## Access Caveats
- **Language:** While most major institutions offer English versions, some national agencies (e.g., Bpifrance) and local newsrooms may publish primarily in their native language (French, German, etc.). Translation tools will be necessary for comprehensive coverage.
- **Paywalls:** First-hand sources (government, universities, company IR) are generally free of paywalls.
- **RSS Availability:** Many government and research sites offer RSS feeds (e.g., EU Commission, Fraunhofer, EPO). However, many company newsrooms and university labs require page scraping.
- **APIs:** Procurement portals like TED offer APIs, but may require registration for bulk access.

## Demoted Secondary Media
The following commonly-used secondary media sources should be demoted to a **verification-only** role, as they aggregate news rather than originate it:
- *The Robot Report*
- *Robotics & Automation News*
- *Robotics Business Review*
- *TechCrunch (Robotics section)*
- *Sifted (European tech news)*
These sources are useful for context and market reaction but should not be cited as the primary origin of a story.
