# Japan Robotics Primary-Source Registry Memo

## Coverage Logic Across Source Types
The coverage strategy for Japan prioritizes direct origination points where robotics news, policy, and financial data first appear. The logic is structured across several key pillars:
1. **Government & Policy**: Sources like METI, NEDO, and MIC are monitored for national robotics strategies, funding announcements, and regulatory frameworks. The Cabinet Office's Moonshot program is also tracked for long-term R&D goals.
2. **Disclosure & Financials**: TDnet and EDINET are critical for real-time financial results, M&A activities, and corporate disclosures from publicly traded robotics companies. These platforms offer APIs for programmatic access, ensuring immediate capture of market-moving news.
3. **Patents & IP**: J-PlatPat is included to track technological advancements and intellectual property filings, providing early indicators of future product developments.
4. **Industry Associations & Exhibitions**: Organizations like JARA, JEMA, and RRI provide industry-wide statistics, standards, and collaborative initiatives. Exhibitions like iREX are monitored for product launches and industry trends.
5. **Research & Academia**: Leading institutes (AIST, RIKEN, ATR) and university labs (JSK Lab) are tracked for breakthrough research and early-stage technologies.
6. **Corporate Newsrooms**: A comprehensive list of major robotics manufacturers (FANUC, Yaskawa, Kawasaki, etc.) and innovative startups (Preferred Networks, Telexistence, GITAI, etc.) ensures coverage of product releases, partnerships, and corporate milestones.

## Top 10 Priority Sources
1. **TDnet (Japan Exchange Group)**: The primary platform for timely disclosure of financial and corporate news by listed companies, essential for real-time market intelligence.
2. **EDINET (Financial Services Agency)**: The official repository for statutory financial filings, providing deep insights into the financial health and strategic direction of robotics firms.
3. **METI Press Releases**: The definitive source for Japan's national industrial policies, funding initiatives, and economic strategies impacting the robotics sector.
4. **NEDO News**: Crucial for tracking government-funded R&D projects and technological breakthroughs in energy and industrial technologies.
5. **FANUC IR Announcements**: As a global leader in CNC and robotics, FANUC's corporate news is a bellwether for the industrial automation market.
6. **Yaskawa News Releases**: Key for updates on motion control, robotics, and systems engineering, reflecting broader trends in manufacturing automation.
7. **Kawasaki Robotics News**: Important for tracking developments in industrial and collaborative robots, as well as new applications in logistics and healthcare.
8. **JARA (Japan Robot Association)**: The authoritative source for industry statistics, market forecasts, and association news in Japan.
9. **AIST Research Highlights**: Provides early visibility into advanced robotics research, including humanoid and industrial applications.
10. **Preferred Networks News**: A leading AI and robotics startup, crucial for tracking the intersection of deep learning and physical automation.

## Monitoring Cadence Advice
- **Daily (P0)**: TDnet, EDINET, METI, and major corporate IR pages (FANUC, Yaskawa, Kawasaki, Mitsubishi Electric, Omron) should be monitored daily for market-moving news and timely disclosures.
- **Weekly (P1)**: NEDO, MIC, J-PlatPat, and other corporate newsrooms should be checked weekly for policy updates, patent filings, and product announcements.
- **Monthly/Event-Driven (P2)**: Associations (JARA, JEMA, RRI), research institutes, and exhibition sites (iREX) can be monitored monthly or around specific events for broader industry trends and statistics.

## Access Caveats
- **Language**: While many sources offer English interfaces or translations, the English content often lags behind the Japanese originals. For real-time intelligence, monitoring the Japanese pages using translation tools or native speakers is recommended.
- **APIs**: TDnet and EDINET offer APIs, which should be leveraged for automated data collection.
- **Paywalls/Logins**: Most government, disclosure, and corporate newsrooms are freely accessible. However, some detailed patent documents on J-PlatPat or specific industry reports may require registration or payment.

## Demotion of Secondary Media
Existing RAI sources that rely on aggregation or secondary reporting should be demoted to a verification-only tier. This includes general news media such as:
- **Nikkei**
- **Japan Times**
- **Kyodo News**
These sources are valuable for cross-referencing and understanding broader market sentiment but should not be counted as primary origination points for robotics news.
